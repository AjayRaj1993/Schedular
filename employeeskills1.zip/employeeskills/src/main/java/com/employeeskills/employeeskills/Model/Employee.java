package com.employeeskills.employeeskills.Model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class Employee {

    @Id
    @Column(name="employeeno")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int employeeID;

    @Column(name="employeename")
    private String empname;

    @Column(name="department")
    private String department;

    @Column(name="yearsofexperience")
    private int yearsofexperience;

    @Column(name="qualification")
    private String qualification;

    @Column(name="certification")
    private String certification;

    @Column(name="technicalskills")
    private String technicalskills;


    public int getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(int employeeID) {
        this.employeeID = employeeID;
    }

    public String getEmpname() {
        return empname;
    }

    public void setEmpname(String empname) {
        this.empname = empname;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getYearsofexperience() {
        return yearsofexperience;
    }

    public void setYearsofexperience(int yearsofexperience) {
        this.yearsofexperience = yearsofexperience;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getCertification() {
        return certification;
    }

    public void setCertification(String certification) {
        this.certification = certification;
    }

    public String getTechnicalskills() {
        return technicalskills;
    }

    public void setTechnicalskills(String technicalskills) {
        this.technicalskills = technicalskills;
    }
}
