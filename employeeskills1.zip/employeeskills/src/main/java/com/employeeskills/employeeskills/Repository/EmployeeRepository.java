package com.employeeskills.employeeskills.Repository;

import com.employeeskills.employeeskills.Model.Employee;
import org.springframework.data.repository.CrudRepository;



// interface extending crud repository
public interface EmployeeRepository extends CrudRepository<Employee, Integer>{

}
